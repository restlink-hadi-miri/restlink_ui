#!/usr/bin/env python3
# Copyright (c) 2025 Hadi Miri. All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# pylint: disable=R0902,E1101,C0301,R0801,E023

import sys
from unittest.mock import MagicMock, patch

import pytest
import rclpy
from geometry_msgs.msg import Pose, PoseStamped
from PyQt5.QtWidgets import QApplication, QStackedWidget
from PyQt5.QtCore import QTimer
from std_msgs.msg import Bool

from restlink_ui.main import MainApplication, RestLinkUINode

# --- Dummy message for testing platoon callback ---
class DummyPlatoon:
    def __init__(self, id=1, name="TestPlatoon", destination="wurzburg"):
        self.id = id
        self.name = name
        self.destination = destination

# --- Fixtures ---

# Fixture for QApplication (required for PyQt tests).
@pytest.fixture(scope="session")
def qt_app():
    app = QApplication(sys.argv)
    yield app
    app.quit()

# Fixture for a minimal ROS node instance.
@pytest.fixture
def ros_node():
    rclpy.init(args=[])
    node = RestLinkUINode()
    # Create a persistent logger so that repeated calls return the same MagicMock.
    my_logger = MagicMock()
    node.get_logger = lambda: my_logger
    node._logger = my_logger  # in case internal code uses _logger
    node.pose_emitter = MagicMock()
    yield node
    node.destroy_node()
    rclpy.shutdown()

# Fixture for MainApplication instance.
@pytest.fixture
def main_app(qt_app, ros_node):
    return MainApplication(ros_node)

# --- Existing Tests ---

def test_publish_message(ros_node):
    dummy_publisher = MagicMock()
    dummy_publisher.topic_name = "/dummy_topic"
    test_message = Bool(data=True)
    ros_node.publish_message(dummy_publisher, test_message)
    dummy_publisher.publish.assert_called_with(test_message)
    logger = ros_node.get_logger()
    # Check that logger.info was called at least once.
    assert logger.info.call_count >= 1

def test_platoon_list_callback(ros_node):
    dummy_msg = DummyPlatoon(id=5, name="TestPlatoon", destination="bamberg")
    ros_node.platoon_list_callback(dummy_msg)
    assert ros_node.platoon_list == dummy_msg
    assert ros_node.platoons_received is True

def test_lv_acceptance_callback(ros_node):
    dummy_bool = Bool(data=True)
    ros_node.lv_acceptance_callback(dummy_bool)
    assert ros_node.lv_acceptance_value is True

def test_ego_pose_callback(ros_node):
    msg = PoseStamped()
    msg.pose = Pose()
    msg.pose.position.x = 2.5
    msg.pose.position.y = 3.5
    dummy_emitter = MagicMock()
    ros_node.pose_emitter = dummy_emitter
    ros_node.ego_pose_callback(msg)
    dummy_emitter.new_pose_signal.emit.assert_called_with(2.5, 3.5)

def test_lv_pose_callback(ros_node):
    msg = PoseStamped()
    msg.pose = Pose()
    msg.pose.position.x = 1.0
    msg.pose.position.y = 4.0
    dummy_emitter = MagicMock()
    ros_node.pose_emitter = dummy_emitter
    ros_node.lv_pose_callback(msg)
    dummy_emitter.new_lv_pose_signal.emit.assert_called_with(1.0, 4.0)

def test_switch_layout(main_app):
    initial_widget = main_app.stack.currentWidget()
    main_app.fade_transition = lambda current, next_widget: main_app.stack.setCurrentWidget(next_widget)
    main_app.switch_layout("home")
    assert main_app.stack.currentWidget() != initial_widget

def test_handle_destination_confirm_valid(qt_app, ros_node):
    app_instance = MainApplication(ros_node)
    destination_page = app_instance.pages["destination"]
    destination_page.text_input.setText("wurzburg")
    ros_node.publish_message = MagicMock()
    app_instance.handle_destination_confirm()
    calls = ros_node.publish_message.call_args_list
    assert len(calls) >= 2
    found_bool = any(call[0][1].__class__.__name__ == "Bool" and call[0][1].data is True for call in calls)
    assert found_bool

def test_handle_destination_confirm_invalid(qt_app, ros_node, capsys):
    app_instance = MainApplication(ros_node)
    destination_page = app_instance.pages["destination"]
    destination_page.text_input.setText("invalidcity")
    ros_node.publish_message = MagicMock()
    app_instance.handle_destination_confirm()
    ros_node.publish_message.assert_not_called()
    captured = capsys.readouterr().out
    assert "Invalid destination" in captured

def test_check_platoons_received(qt_app, ros_node):
    app_instance = MainApplication(ros_node)
    app_instance.stack.setCurrentWidget(app_instance.pages["loading"])
    dummy_msg = DummyPlatoon(id=10, name="TestPlatoon", destination="bamberg")
    ros_node.platoon_list = dummy_msg
    original_switch_layout = app_instance.switch_layout
    app_instance.switch_layout = MagicMock()
    app_instance.check_platoons_received()
    app_instance.switch_layout.assert_called_with("platoon")
    app_instance.switch_layout = original_switch_layout

def test_handle_restlink_click(qt_app, ros_node):
    app_instance = MainApplication(ros_node)
    app_instance.fade_transition = lambda current, next_widget: app_instance.stack.setCurrentWidget(next_widget)
    with patch("restlink_ui.main.subprocess.Popen") as mock_popen:
        app_instance.launch_started = False
        app_instance.handle_restlink_click()
        mock_popen.assert_called_with(["ros2", "launch", "rl_launch", "rl_launch.py"])
        assert app_instance.stack.currentWidget() == app_instance.pages["home"]

def test_handle_emergency_stop(qt_app, ros_node):
    app_instance = MainApplication(ros_node)
    ros_node.publish_message = MagicMock()
    app_instance.handle_emergency_stop()
    ros_node.publish_message.assert_any_call(ros_node.emergency_stop_publisher, Bool(data=True))
    app_instance.reset_ui_after_emergency()
    assert app_instance.stack.currentWidget() == app_instance.pages["app"]

def test_toggle_theme_acceptance(qt_app):
    from restlink_ui.acceptance.acceptance import AcceptanceScreen
    stack = QStackedWidget()
    screen = AcceptanceScreen(stack)
    if not hasattr(screen, "toggle_theme"):
        def dummy_toggle_theme():
            screen.dark_mode = not screen.dark_mode
            screen.apply_theme()
        screen.toggle_theme = dummy_toggle_theme
    initial_style = stack.styleSheet()
    screen.dark_mode = False
    screen.toggle_theme()
    new_style = stack.styleSheet()
    assert new_style != initial_style

def test_driving_screen_update_position(qt_app):
    from restlink_ui.map.map import DrivingScreen
    stack = QStackedWidget()
    driving_screen = DrivingScreen(stack)
    driving_screen.zoom_factor = 1.0
    driving_screen.map_widget.setGeometry(0, 0, 400, 400)
    driving_screen.transform_coordinates = lambda x, y: (50, 350)
    driving_screen.update_position(2.0, 3.0)
    expected_x, expected_y = driving_screen.transform_coordinates(200, 300)
    actual_pos = driving_screen.ego_marker.pos()
    assert actual_pos.x() == expected_x
    assert actual_pos.y() == expected_y

def test_driving_screen_zoom(qt_app):
    from restlink_ui.map.map import DrivingScreen
    stack = QStackedWidget()
    driving_screen = DrivingScreen(stack)
    initial_zoom = driving_screen.zoom_factor
    driving_screen.zoom_in()
    assert driving_screen.zoom_factor > initial_zoom
    driving_screen.zoom_factor = 1.0
    driving_screen.zoom_out()
    assert driving_screen.zoom_factor == 1.0

# --- Additional Tests for main.py to Increase Coverage ---

def test_main_function(monkeypatch):
    """
    Test main() in main.py by patching out ROS initialization, spinning, and threading.
    We bypass ROS spinning by patching rclpy.spin and the module-level ros_spin,
    and we patch the QApplication constructor so that no real Qt initialization occurs.
    Also, we patch threading.Thread so that its start() does nothing.
    """
    import restlink_ui.main as main_mod
    exit_code = 0

    # Patch RestLinkUINode.__init__ to bypass real ROS initialization.
    def fake_restlinkuinode_init(self, *args, **kwargs):
        self.pose_emitter = MagicMock()
        self.platoon_list = None
        self.platoons_received = False
        self.lv_acceptance_value = None
        self.create_publisher = lambda *a, **kw: MagicMock()
        self.create_subscription = lambda *a, **kw: None
        self.get_logger = lambda: MagicMock()
    monkeypatch.setattr(main_mod.RestLinkUINode, "__init__", fake_restlinkuinode_init)

    # Patch QApplication.__init__ so no real initialization occurs.
    monkeypatch.setattr(main_mod.QtWidgets.QApplication, "__init__", lambda self, argv: None)
    # Patch QApplication.exec_ to return our exit code.
    monkeypatch.setattr(main_mod.QtWidgets.QApplication, "exec_", lambda self: exit_code)

    # Capture sys.exit calls.
    captured_exit = []
    monkeypatch.setattr(main_mod.sys, "exit", lambda code: captured_exit.append(code))

    # Patch rclpy init/shutdown and destroy_node.
    monkeypatch.setattr(main_mod.rclpy, "init", lambda args=None: None)
    monkeypatch.setattr(main_mod.rclpy, "shutdown", lambda: None)
    monkeypatch.setattr(main_mod.RestLinkUINode, "destroy_node", lambda self: None)

    # Patch rclpy.spin and module-level ros_spin to no-ops.
    monkeypatch.setattr(main_mod.rclpy, "spin", lambda node: None)
    monkeypatch.setattr(main_mod, "ros_spin", lambda node: None)

    # Patch threading.Thread so that its start() does nothing.
    class FakeThread:
        def __init__(self, target, args, daemon):
            self.target = target
            self.args = args
        def start(self):
            pass
    monkeypatch.setattr(main_mod.threading, "Thread", FakeThread)

    main_mod.main([])
    assert captured_exit == [exit_code]

def test_publish_platoon_id(ros_node):
    from std_msgs.msg import Int32
    from restlink_ui.main import MainApplication
    dummy_platoon = DummyPlatoon(id=42, name="Dummy", destination="dummy")
    ros_node.platoon_list = dummy_platoon
    ros_node.publish_message = MagicMock()
    app_instance = MainApplication(ros_node)
    app_instance.publish_platoon_id()
    ros_node.publish_message.assert_called_once()
    call_args = ros_node.publish_message.call_args[0]
    assert isinstance(call_args[1], Int32)
    assert call_args[1].data == 42

def test_publish_find_new_platoon_msgs(ros_node):
    ros_node.publish_message = MagicMock()
    from restlink_ui.main import MainApplication
    app_instance = MainApplication(ros_node)
    app_instance.publish_find_new_platoon_msgs()
    assert ros_node.publish_message.call_count >= 2

def test_stop_platoon_id_timer(qt_app, ros_node):
    from restlink_ui.main import MainApplication
    app_instance = MainApplication(ros_node)
    app_instance.platoon_id_timer.start(100)
    app_instance.stop_platoon_id_timer()
    assert not app_instance.platoon_id_timer.isActive()

def test_get_current_layout_key(main_app):
    assert main_app.get_current_layout_key() == "app"

def test_handle_join_platoon(qt_app, ros_node):
    from restlink_ui.main import MainApplication
    app_instance = MainApplication(ros_node)
    dummy_platoon = DummyPlatoon(id=7, name="Test", destination="wurzburg")
    ros_node.platoon_list = dummy_platoon
    ros_node.publish_message = MagicMock()
    app_instance.handle_join_platoon()
    ros_node.publish_message.assert_any_call(ros_node.platoon_found_publisher, Bool(data=True))
    assert app_instance.platoon_id_timer.isActive()

def test_handle_find_new_platoon(qt_app, ros_node):
    from restlink_ui.main import MainApplication
    app_instance = MainApplication(ros_node)
    ros_node.publish_message = MagicMock()
    app_instance.platoon_id_timer.start(100)
    called = False
    original_stop = app_instance.stop_platoon_id_timer
    def fake_stop():
        nonlocal called
        called = True
        original_stop()
    app_instance.stop_platoon_id_timer = fake_stop
    app_instance.handle_find_new_platoon()
    assert called
    assert app_instance.find_new_platoon_timer.isActive()

def test_handle_exit_sequence(monkeypatch, qt_app, ros_node):
    from restlink_ui.main import MainApplication
    app_instance = MainApplication(ros_node)
    ros_node.publish_message = MagicMock()
    dummy_pose = Pose()
    dummy_pose.position.x = 1.0
    dummy_pose.position.y = 2.0
    dummy_pose.position.z = 0.0
    dummy_pose.orientation.w = 1.0
    app_instance.last_pose = dummy_pose
    monkeypatch.setattr(QTimer, "singleShot", lambda timeout, func: func())
    app_instance.handle_exit_sequence()
    calls = ros_node.publish_message.call_args_list
    topics = [call[0][0] for call in calls]
    assert ros_node.exit_platoon_publisher in topics
    assert ros_node.is_destination_publisher in topics

def test_handle_go_to_app_layout(qt_app, ros_node):
    from restlink_ui.main import MainApplication
    app_instance = MainApplication(ros_node)
    app_instance.last_layout_key = "home"
    captured = []
    def fake_switch_layout(page_key):
        captured.append(page_key)
    app_instance.switch_layout = fake_switch_layout
    app_instance.handle_go_to_app_layout()
    assert captured[0] == "app"

def test_reset_ui_after_emergency(qt_app, ros_node):
    from restlink_ui.main import MainApplication
    app_instance = MainApplication(ros_node)
    ros_node.publish_message = MagicMock()
    app_instance.platoon_id_timer.start(100)
    app_instance.find_new_platoon_timer.start(100)
    app_instance.reset_ui_after_emergency()
    assert app_instance.stack.currentWidget() == app_instance.pages["app"]

