#!/usr/bin/env python3
# Copyright (c) 2025 Hadi Miri. All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# pylint: disable=R0902,E1101,C0301,R0801,E023
import os
import sys
from datetime import datetime

from PyQt5 import QtCore, QtGui, QtWidgets


class ClickableRestLinkUI(QtWidgets.QWidget):
    def __init__(self, stack):
        super().__init__()
        self.stack = stack
        self.init_ui()
        self.setFixedSize(1000, 750)

    def init_ui(self):
        self.setStyleSheet("background-color: black;")
        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)

        # Background Label
        self.background_label = QtWidgets.QLabel(self)
        self.background_label.setAlignment(QtCore.Qt.AlignCenter)
        self.background_label.setStyleSheet("background-color: black;")

        # Time Label
        self.time_label = QtWidgets.QLabel(self)
        self.time_label.setStyleSheet(
            """
            color: white;
            font-size: 24px;
            font-weight: bold;
            background: transparent;
        """
        )
        self.time_label.setAlignment(QtCore.Qt.AlignLeft | QtCore.Qt.AlignTop)
        self.time_label.setGeometry(20, 20, 200, 40)

        # Timer Setup
        self.timer = QtCore.QTimer(self)
        self.timer.timeout.connect(self.update_clock)
        self.timer.start(1000)
        self.update_clock()

        # Image Setup
        self.update_background()
        layout.addWidget(self.background_label)

        # RestLink Button
        self.restlink_button = QtWidgets.QPushButton("", self)
        self.set_button_position()
        self.restlink_button.setStyleSheet(
            """
            background: transparent;
            border: none;
            transition: background 0.3s ease-in-out;
        """
        )
        self.restlink_button.setCursor(QtGui.QCursor(QtCore.Qt.PointingHandCursor))
        self.restlink_button.installEventFilter(self)

        self.setLayout(layout)
        self.setWindowTitle("Clickable RestLink UI")

    def update_clock(self):
        current_time = datetime.now().strftime("%H:%M:%S")
        self.time_label.setText(current_time)

    def update_background(self):
        base_dir = os.path.dirname(os.path.abspath(__file__))
        background_path = os.path.join(base_dir, "background.png")
        pixmap = QtGui.QPixmap(background_path)

        if pixmap.isNull():
            print("Warning: Could not load background image from", background_path)
        else:
            print("Loaded background image from", background_path)

        pixmap = pixmap.scaled(
            self.width(),
            self.height(),
            QtCore.Qt.KeepAspectRatio,
            QtCore.Qt.SmoothTransformation,
        )
        self.background_label.setPixmap(pixmap)
        self.background_label.setGeometry(0, 0, self.width(), self.height())

    def set_button_position(self):
        button_x = 730
        button_y = 380
        button_width = 160
        button_height = 160
        self.restlink_button.setGeometry(
            button_x, button_y, button_width, button_height
        )
        self.restlink_button.clicked.connect(self.button_clicked)

    def button_clicked(self):
        print("RestLink button clicked!")

    def resizeEvent(self, event):
        self.update_background()

    def eventFilter(self, obj, event):
        if obj == self.restlink_button:
            if event.type() == QtCore.QEvent.Enter:
                self.restlink_button.setStyleSheet(
                    "background: rgba(255, 255, 255, 60); border-radius: 20px; transition: background 0.3s ease-in-out;"
                )
            elif event.type() == QtCore.QEvent.Leave:
                self.restlink_button.setStyleSheet(
                    "background: transparent; border: none; transition: background 0.3s ease-in-out;"
                )
        return super().eventFilter(obj, event)


if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    stack = QtWidgets.QStackedWidget()
    clickable_ui = ClickableRestLinkUI(stack)
    stack.addWidget(clickable_ui)
    stack.show()
    sys.exit(app.exec_())
