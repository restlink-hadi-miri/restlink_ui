#!/usr/bin/env python3
# Copyright (c) 2025 Hadi Miri. All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# pylint: disable=R0902,E1101,C0301,R0801,E023
import os
import sys

from PyQt5 import QtCore, QtGui, QtWidgets


class CityPopup(QtWidgets.QDialog):
    """Simple popup dialog that displays a city image with a fade-in
    animation."""

    def __init__(self, pixmap: QtGui.QPixmap, parent=None):
        super().__init__(parent)
        self.setWindowFlags(QtCore.Qt.Popup | QtCore.Qt.FramelessWindowHint)
        self.setAttribute(QtCore.Qt.WA_TranslucentBackground, True)
        self.setModal(False)

        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)

        self.label = QtWidgets.QLabel()
        self.label.setPixmap(pixmap)
        layout.addWidget(self.label)
        self.setLayout(layout)

        # Fade-in animation
        self.effect = QtWidgets.QGraphicsOpacityEffect(self)
        self.setGraphicsEffect(self.effect)
        self.animation = QtCore.QPropertyAnimation(self.effect, b"opacity", self)
        self.animation.setDuration(300)
        self.animation.setStartValue(0.0)
        self.animation.setEndValue(1.0)

    def show_popup(self, global_pos: QtCore.QPoint):
        self.move(global_pos)
        self.animation.start()
        self.show()

    def close_popup(self):
        self.close()


class DraggableLabel(QtWidgets.QLabel):
    """A label to display the pointer.png (with transparency).

    It can be dragged around the map. When the user releases, we notify
    the parent.
    """

    def __init__(self, parent=None):
        super().__init__(parent)
        self.dragging = False
        self.offset = QtCore.QPoint(0, 0)
        self.setAttribute(QtCore.Qt.WA_TranslucentBackground)
        self.setStyleSheet("background: transparent; border: none;")

    def mousePressEvent(self, event):
        if event.button() == QtCore.Qt.LeftButton:
            self.dragging = True
            self.offset = event.pos()

    def mouseMoveEvent(self, event):
        if self.dragging:
            # Calculate new position based on mouse movement:
            dx = event.x() - self.offset.x()
            dy = event.y() - self.offset.y()
            new_x = self.x() + dx
            new_y = self.y() + dy

            # Clamp the pointer within the parent's boundaries (the map)
            if self.parent():
                parent_width = self.parent().width()
                parent_height = self.parent().height()
                pointer_width = self.width()
                pointer_height = self.height()
                new_x = max(0, min(new_x, parent_width - pointer_width))
                new_y = max(0, min(new_y, parent_height - pointer_height))

            self.move(new_x, new_y)

    def mouseReleaseEvent(self, event):
        if event.button() == QtCore.Qt.LeftButton:
            self.dragging = False
            # Notify parent that pointer is released (which checks if it landed
            # on a city)
            if self.parent() and hasattr(self.parent(), "pointer_released"):
                self.parent().pointer_released()


class MapWidget(QtWidgets.QLabel):
    """Displays the map, bounding boxes for each city, plus a draggable
    pointer.

    Clicking on the map (or releasing the pointer) in a city area
    selects that city.
    """

    mapClicked = QtCore.pyqtSignal(QtCore.QPoint)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAlignment(QtCore.Qt.AlignCenter)
        self.setScaledContents(True)
        self.city_popup = None
        self.pointer_label = None

        # The bounding boxes for ~700×700 reference space:
        self.city_areas = [
            (0, 120, 150, 320, "Kronach", "kronach.png"),
            (0, 450, 150, 620, "Wurzburg", "wurzburg.png"),
            (200, 500, 360, 700, "Bamberg", "bamberg.png"),
            (230, 100, 370, 300, "Lichtenfels", "lichtenfels.png"),
            (500, 270, 680, 470, "Coburg", "coburg.png"),
        ]

    def mousePressEvent(self, event: QtGui.QMouseEvent):
        # When clicking on the map (outside the pointer), check if a city area
        # was clicked.
        if event.button() == QtCore.Qt.LeftButton:
            click_pos = event.pos()
            matched = self.check_city_area(click_pos)
            if not matched and self.city_popup and self.city_popup.isVisible():
                self.city_popup.close_popup()
                self.city_popup = None
            self.mapClicked.emit(click_pos)

    def pointer_released(self):
        """Called by DraggableLabel when the user drops or clicks the pointer.

        Checks if the pointer's center is in a city area.
        """
        if not self.pointer_label:
            return

        center_x = self.pointer_label.x() + self.pointer_label.width() // 2
        center_y = self.pointer_label.y() + self.pointer_label.height() // 2
        pointer_pos = QtCore.QPoint(center_x, center_y)
        self.check_city_area(pointer_pos)

    def check_city_area(self, pos: QtCore.QPoint) -> bool:
        """Transforms `pos` to 700x700 coords.

        If inside a bounding box, update parent's QLineEdit and show the
        city popup.
        """
        w = self.width()
        h = self.height()
        base_w, base_h = 700.0, 700.0
        scale_x = base_w / w
        scale_y = base_h / h

        adj_x = pos.x() * scale_x
        adj_y = pos.y() * scale_y

        for x1, y1, x2, y2, cityName, cityImg in self.city_areas:
            if x1 <= adj_x <= x2 and y1 <= adj_y <= y2:
                # Update parent's QLineEdit regardless of how the click came
                # in.
                if hasattr(self.parentWidget(), "set_destination_text"):
                    self.parentWidget().set_destination_text(cityName)
                self.show_city_popup(cityImg, pos)
                return True
        return False

    def show_city_popup(self, city_image: str, click_pos: QtCore.QPoint):
        # Close existing popup if one is open
        if self.city_popup and self.city_popup.isVisible():
            self.city_popup.close_popup()
            self.city_popup = None

        base_dir = os.path.dirname(os.path.abspath(__file__))
        path = os.path.join(base_dir, city_image)
        pix = QtGui.QPixmap(path)
        if pix.isNull():
            print(f"Warning: city image not found: {city_image}")
            return

        self.city_popup = CityPopup(pix, self)
        offset_pos = click_pos + QtCore.QPoint(10, 10)
        global_pos = self.mapToGlobal(offset_pos)
        self.city_popup.show_popup(global_pos)

    def set_map_pixmap(self, pixmap: QtGui.QPixmap):
        self.setPixmap(pixmap)

    def add_pointer(self, pointer_pixmap: QtGui.QPixmap):
        """Creates a DraggableLabel for the pointer, sets it with transparency,
        and places it on the map."""
        if pointer_pixmap.isNull():
            print("Warning: pointer pixmap is empty.")
            return

        self.pointer_label = DraggableLabel(self)
        self.pointer_label.setPixmap(pointer_pixmap)
        self.pointer_label.resize(pointer_pixmap.size())
        # Place the pointer near the top-left initially
        self.pointer_label.move(50, 50)
        self.pointer_label.raise_()
        self.pointer_label.show()


class DestinationMenu(QtWidgets.QWidget):
    """
    Main widget: top bar, logo, destination input, map, and a draggable pointer.
    """

    def __init__(self, stack):
        super().__init__()
        self.stack = stack
        self.dark_mode = False
        self.init_ui()
        self.setFixedSize(1000, 800)

    def init_ui(self):
        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(10, 10, 10, 10)
        layout.setSpacing(5)

        # ───────── Top Bar ─────────
        top_bar = QtWidgets.QHBoxLayout()
        self.home_button = QtWidgets.QPushButton()
        self.home_button.setIcon(self.load_icon("home.png"))
        self.home_button.setFixedSize(40, 40)
        self.home_button.setStyleSheet(
            "border: none; background: transparent; margin-left: 5px;"
        )
        self.home_button.clicked.connect(lambda: self.stack.setCurrentIndex(0))

        self.stop_button = QtWidgets.QPushButton()
        self.stop_button.setIcon(self.load_icon("stop.png"))
        self.stop_button.setFixedSize(32, 32)
        self.stop_button.setStyleSheet(
            "border: none; background: transparent; margin-right: 5px;"
        )
        self.stop_button.clicked.connect(self.stop_action)

        self.theme_button = QtWidgets.QPushButton()
        self.theme_button.setIcon(self.load_icon("b.png"))
        self.theme_button.setFixedSize(32, 32)
        self.theme_button.setStyleSheet(
            "border: none; background: transparent; margin-right: 5px;"
        )
        self.theme_button.clicked.connect(self.toggle_theme)

        top_bar.addWidget(self.home_button, alignment=QtCore.Qt.AlignLeft)
        top_bar.addStretch()
        top_bar.addWidget(self.stop_button, alignment=QtCore.Qt.AlignRight)
        top_bar.addWidget(self.theme_button, alignment=QtCore.Qt.AlignRight)
        layout.addLayout(top_bar)

        # ───────── Logo ─────────
        logo_label = QtWidgets.QLabel()
        logo_pix = self.load_pixmap("logo.png", 80, 80)
        logo_label.setPixmap(logo_pix)
        logo_label.setAlignment(QtCore.Qt.AlignCenter)
        layout.addWidget(logo_label)

        # ───────── Title ─────────
        title_label = QtWidgets.QLabel("Please enter your destination")
        title_label.setAlignment(QtCore.Qt.AlignCenter)
        title_label.setStyleSheet(
            "font-size: 20px; font-weight: bold; background: transparent;"
        )
        layout.addWidget(title_label)

        # ───────── Input ─────────
        self.text_input = QtWidgets.QLineEdit()
        self.text_input.setPlaceholderText("Type your destination here...")
        self.text_input.setFixedSize(400, 40)
        self.text_input.setAlignment(QtCore.Qt.AlignCenter)
        self.text_input.setStyleSheet(
            "font-size: 16px; padding: 5px; border: 2px solid grey; border-radius: 10px;"
        )
        txt_layout = QtWidgets.QHBoxLayout()
        txt_layout.addStretch()
        txt_layout.addWidget(self.text_input)
        txt_layout.addStretch()
        layout.addLayout(txt_layout)

        # ───────── Buttons ─────────
        btn_layout = QtWidgets.QHBoxLayout()
        self.confirm_button = QtWidgets.QPushButton("Confirm")
        self.confirm_button.setFixedSize(120, 40)
        self.confirm_button.setStyleSheet("background-color: grey; font-size: 16px;")
        self.confirm_button.clicked.connect(self.confirm_destination)

        self.reset_button = QtWidgets.QPushButton("Reset")
        self.reset_button.setFixedSize(120, 40)
        self.reset_button.setStyleSheet("background-color: grey; font-size: 16px;")
        self.reset_button.clicked.connect(self.reset_text)

        btn_layout.addStretch()
        btn_layout.addWidget(self.confirm_button)
        btn_layout.addWidget(self.reset_button)
        btn_layout.addStretch()
        layout.addLayout(btn_layout)

        # ───────── Map ─────────
        map_layout = QtWidgets.QHBoxLayout()
        map_layout.setContentsMargins(0, 10, 0, 5)

        self.map_widget = MapWidget(self)
        map_pix = self.load_map("map_point.png")
        scaled_map = map_pix.scaled(
            400, 400, QtCore.Qt.KeepAspectRatio, QtCore.Qt.SmoothTransformation
        )
        self.map_widget.set_map_pixmap(scaled_map)

        # Add pointer (scaled larger, with no forced background)
        pointer_path = os.path.join(os.path.dirname(__file__), "pointer.png")
        pointer_pix = QtGui.QPixmap(pointer_path)
        if not pointer_pix.isNull():
            # Increase pointer size to 80x80 (adjust as needed)
            pointer_pix = pointer_pix.scaled(
                80, 80, QtCore.Qt.KeepAspectRatio, QtCore.Qt.SmoothTransformation
            )
            self.map_widget.add_pointer(pointer_pix)
        else:
            print("Warning: pointer.png not found or invalid.")

        map_layout.addStretch()
        map_layout.addWidget(self.map_widget)
        map_layout.addStretch()
        layout.addLayout(map_layout)

        layout.addStretch()
        self.setLayout(layout)
        self.setWindowTitle("RestLink - Destination Entry")
        self.apply_theme()

    def set_destination_text(self, city_name: str):
        self.text_input.setText(city_name)

    def confirm_destination(self):
        destination = self.text_input.text()
        print(f"Destination Confirmed: {destination}")

    def reset_text(self):
        self.text_input.clear()

    def toggle_theme(self):
        self.dark_mode = not self.dark_mode
        self.apply_theme()

    def stop_action(self):
        print("Stop button clicked")

    def apply_theme(self):
        if self.dark_mode:
            self.stack.setStyleSheet("background: #222; color: white;")
        else:
            self.stack.setStyleSheet("background: white; color: black;")
        self.theme_button.setIcon(self.load_icon("b.png"))

    def load_icon(self, filename: str) -> QtGui.QIcon:
        base_dir = os.path.dirname(os.path.abspath(__file__))
        path = os.path.join(base_dir, filename)
        return QtGui.QIcon(path) if os.path.exists(path) else QtGui.QIcon()

    def load_pixmap(self, filename: str, width: int, height: int) -> QtGui.QPixmap:
        base_dir = os.path.dirname(os.path.abspath(__file__))
        path = os.path.join(base_dir, filename)
        pix = QtGui.QPixmap(path)
        if pix.isNull():
            print(f"Warning: Could not load {path}")
            return QtGui.QPixmap()
        return pix.scaled(
            width, height, QtCore.Qt.KeepAspectRatio, QtCore.Qt.SmoothTransformation
        )

    def load_map(self, filename: str) -> QtGui.QPixmap:
        base_dir = os.path.dirname(os.path.abspath(__file__))
        path = os.path.join(base_dir, filename)
        pix = QtGui.QPixmap(path)
        if pix.isNull():
            print(f"Warning: Could not load map from {path}")
        return pix


if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    stack = QtWidgets.QStackedWidget()
    destination_menu = DestinationMenu(stack)
    stack.addWidget(destination_menu)
    stack.show()
    sys.exit(app.exec_())
