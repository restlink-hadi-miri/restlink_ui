#!/usr/bin/env python3
# Copyright (c) 2025 Hadi Miri. All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# pylint: disable=R0902,E1101,C0301,R0801,E023
import os
import sys

from PyQt5 import QtCore, QtGui, QtWidgets

# DraggableScrollArea: Allows panning (dragging) the map.


class DraggableScrollArea(QtWidgets.QScrollArea):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWidgetResizable(False)
        self.setHorizontalScrollBarPolicy(QtCore.Qt.ScrollBarAlwaysOff)
        self.setVerticalScrollBarPolicy(QtCore.Qt.ScrollBarAlwaysOff)
        self._dragging = False
        self._drag_start_x = 0
        self._drag_start_y = 0

    def mousePressEvent(self, event):
        if event.button() == QtCore.Qt.LeftButton:
            self._dragging = True
            self._drag_start_x = event.x()
            self._drag_start_y = event.y()
            self.setCursor(QtCore.Qt.ClosedHandCursor)
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event):
        if self._dragging:
            dx = event.x() - self._drag_start_x
            dy = event.y() - self._drag_start_y
            hBar = self.horizontalScrollBar()
            vBar = self.verticalScrollBar()
            hBar.setValue(hBar.value() - dx)
            vBar.setValue(vBar.value() - dy)
            self._drag_start_x = event.x()
            self._drag_start_y = event.y()
        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event):
        self._dragging = False
        self.setCursor(QtCore.Qt.ArrowCursor)
        super().mouseReleaseEvent(event)


# DrivingScreen: Main widget with top bar, logo, title, and
# zoomable/pannable map.
class DrivingScreen(QtWidgets.QWidget):
    def __init__(self, stack):
        super().__init__()
        self.stack = stack
        self.dark_mode = False
        self.zoom_factor = 1.0  # Minimum zoom factor is 1.0 (400x400 map)
        # Store current coordinates (multiplied by 100) for markers.
        # dummy initial coordinate for ego marker
        self.current_ego_coords = (100, 100)
        # dummy initial coordinate for LV marker
        self.current_lv_coords = (150, 150)
        self.init_ui()
        self.setFixedSize(1000, 750)

    def init_ui(self):
        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        # --- Top Bar Setup ---
        self.home_button = QtWidgets.QPushButton()
        self.home_button.setIcon(self.load_icon("home.png"))
        self.home_button.setIconSize(QtCore.QSize(32, 32))
        self.home_button.setFixedSize(40, 40)
        self.home_button.setStyleSheet("border: none; background: transparent;")
        self.home_button.clicked.connect(self.go_home)

        self.exit_button = QtWidgets.QPushButton("Exit the Platoon")
        self.exit_button.setFixedSize(200, 40)
        self.exit_button.setStyleSheet(
            "background-color: red; font-size: 16px; font-weight: bold; color: white;"
        )

        self.stop_button = QtWidgets.QPushButton()
        self.stop_button.setIcon(self.load_icon("stop.png"))
        self.stop_button.setFixedSize(32, 32)
        self.stop_button.setStyleSheet(
            "border: none; background: transparent; margin-right: 5px;"
        )
        self.stop_button.clicked.connect(self.stop_action)

        self.theme_button = QtWidgets.QPushButton()
        self.theme_button.setIcon(self.load_icon("b.png"))
        self.theme_button.setFixedSize(32, 32)
        self.theme_button.setStyleSheet("border: none; background: transparent;")
        self.theme_button.clicked.connect(self.toggle_theme)

        top_bar = QtWidgets.QHBoxLayout()
        top_bar.addWidget(self.home_button)
        top_bar.addStretch()
        top_bar.addWidget(self.exit_button)
        top_bar.addStretch()
        top_bar.addWidget(self.stop_button)
        top_bar.addWidget(self.theme_button)

        layout.addLayout(top_bar)

        # --- Logo Setup ---
        logo_label = QtWidgets.QLabel()
        logo_pixmap = self.load_pixmap("logo.png", 200, 200)
        logo_label.setPixmap(logo_pixmap)
        logo_label.setAlignment(QtCore.Qt.AlignCenter)
        layout.addWidget(logo_label)

        # --- Title Label with Animation ---
        self.title_label = QtWidgets.QLabel("Driving to the Platoon")
        self.title_label.setAlignment(QtCore.Qt.AlignCenter)
        self.title_label.setStyleSheet(
            "font-size: 26px; font-weight: bold; background: transparent;"
        )
        layout.addWidget(self.title_label)

        self.timer = QtCore.QTimer()
        self.timer.timeout.connect(self.update_title_animation)
        self.timer.start(500)
        self.dot_count = 0

        # --- Map Setup within a Draggable Scroll Area ---
        self.map_scroll = DraggableScrollArea(self)
        self.map_scroll.setFixedSize(400, 400)

        # The map_widget holds the map image and markers.
        self.map_widget = QtWidgets.QWidget()
        self.map_widget.setFixedSize(400, 400)
        self.map_scroll.setWidget(self.map_widget)

        # Load and display the map image.
        self.original_map_pixmap = self.load_pixmap("map.png", 400, 400)
        self.map_label = QtWidgets.QLabel(self.map_widget)
        self.map_label.setPixmap(self.original_map_pixmap)
        self.map_label.setGeometry(0, 0, 400, 400)

        # --- Marker Setup ---
        # Load raw pixmaps for markers (they remain as in the original PNG,
        # with transparency).
        self.original_ego_pixmap = self.load_raw_pixmap("hv.png")
        self.original_lv_pixmap = self.load_raw_pixmap("lv.png")

        initial_marker_size = 48

        # host vehicle
        scaled_ego = self.original_ego_pixmap.scaled(
            initial_marker_size,
            initial_marker_size,
            QtCore.Qt.KeepAspectRatio,
            QtCore.Qt.SmoothTransformation,
        )
        self.ego_marker = QtWidgets.QLabel(self.map_widget)
        self.ego_marker.setPixmap(scaled_ego)
        self.ego_marker.adjustSize()
        # Ensure QLabel has a transparent background
        self.ego_marker.setStyleSheet("background: transparent;")
        ego_x, ego_y = self.transform_coordinates(*self.current_ego_coords)
        self.ego_marker.move(ego_x, ego_y)

        # lead vehicle
        scaled_lv = self.original_lv_pixmap.scaled(
            initial_marker_size,
            initial_marker_size,
            QtCore.Qt.KeepAspectRatio,
            QtCore.Qt.SmoothTransformation,
        )
        self.lv_marker = QtWidgets.QLabel(self.map_widget)
        self.lv_marker.setPixmap(scaled_lv)
        self.lv_marker.adjustSize()
        # Ensure QLabel has a transparent background
        self.lv_marker.setStyleSheet("background: transparent;")
        lv_x, lv_y = self.transform_coordinates(*self.current_lv_coords)
        self.lv_marker.move(lv_x, lv_y)

        # --- Zoom Buttons Setup (Static) ---
        # The zoom buttons are re-parented to the scroll area's viewport so
        # they remain static.
        self.zoom_in_button = QtWidgets.QPushButton("+", self.map_scroll.viewport())
        self.zoom_in_button.setStyleSheet(
            "background-color: transparent; border: none; "
            "font-weight: bold; font-size: 18px; color: black;"
        )
        self.zoom_in_button.clicked.connect(self.zoom_in)
        self.zoom_in_button.setGeometry(400 - 40, 10, 30, 30)

        self.zoom_out_button = QtWidgets.QPushButton("-", self.map_scroll.viewport())
        self.zoom_out_button.setStyleSheet(
            "background-color: transparent; border: none; "
            "font-weight: bold; font-size: 18px; color: black;"
        )
        self.zoom_out_button.clicked.connect(self.zoom_out)
        self.zoom_out_button.setGeometry(400 - 40, 50, 30, 30)

        layout.addWidget(self.map_scroll, alignment=QtCore.Qt.AlignCenter)
        self.setLayout(layout)
        self.setWindowTitle("RestLink Driving Page")
        self.apply_theme()

    # Timer callback to animate the title.
    def update_title_animation(self):
        dots = "." * ((self.dot_count % 3) + 1)
        self.title_label.setText(f"Driving to the Platoon{dots}")
        self.dot_count += 1

    # Slot: Update the ego marker's position.
    @QtCore.pyqtSlot(float, float)
    def update_position(self, real_x, real_y):
        if not self.isVisible():
            return
        # Multiply coordinates as per conversion.
        real_x = real_x * 100
        real_y = real_y * 100
        self.current_ego_coords = (real_x, real_y)
        pixel_x, pixel_y = self.transform_coordinates(real_x, real_y)
        self.ego_marker.move(pixel_x, pixel_y)

    # Slot: Update the leading vehicle marker's position.
    @QtCore.pyqtSlot(float, float)
    def update_lv_position(self, lv_x, lv_y):
        if not self.isVisible():
            return
        lv_x = lv_x * 100
        lv_y = lv_y * 100
        self.current_lv_coords = (lv_x, lv_y)
        pixel_x, pixel_y = self.transform_coordinates(lv_x, lv_y)
        self.lv_marker.move(pixel_x, pixel_y)

    # Transform coordinates (assumed in an 800x800 space) into pixel coordinates
    # based on the current zoom factor.
    def transform_coordinates(self, real_x, real_y):
        effective_size = 400 * self.zoom_factor
        scale_factor = effective_size / 800
        pixel_x = real_x * scale_factor
        pixel_y = effective_size - (real_y * scale_factor)
        return int(pixel_x), int(pixel_y)

    # Increase zoom factor and update the map and markers.
    def zoom_in(self):
        if self.zoom_factor < 2.0:
            self.zoom_factor += 0.1
            self.update_map_zoom()

    # Decrease zoom factor and update the map and markers.
    # The minimum zoom factor is 1.0 so the map does not become smaller than
    # 400x400.
    def zoom_out(self):
        if self.zoom_factor > 1.0:
            self.zoom_factor -= 0.1
            self.update_map_zoom()

    # Update the map widget, re-scale the map image and reposition markers.
    def update_map_zoom(self):
        new_size = int(400 * self.zoom_factor)
        self.map_widget.setFixedSize(new_size, new_size)
        self.map_label.setGeometry(0, 0, new_size, new_size)
        scaled_map = self.original_map_pixmap.scaled(
            new_size,
            new_size,
            QtCore.Qt.KeepAspectRatio,
            QtCore.Qt.SmoothTransformation,
        )
        self.map_label.setPixmap(scaled_map)

        # Update markers' sizes and reposition them.
        marker_size = int(32 * self.zoom_factor)
        scaled_ego = self.original_ego_pixmap.scaled(
            marker_size,
            marker_size,
            QtCore.Qt.KeepAspectRatio,
            QtCore.Qt.SmoothTransformation,
        )
        self.ego_marker.setPixmap(scaled_ego)
        self.ego_marker.adjustSize()
        ego_x, ego_y = self.transform_coordinates(*self.current_ego_coords)
        self.ego_marker.move(ego_x, ego_y)

        scaled_lv = self.original_lv_pixmap.scaled(
            marker_size,
            marker_size,
            QtCore.Qt.KeepAspectRatio,
            QtCore.Qt.SmoothTransformation,
        )
        self.lv_marker.setPixmap(scaled_lv)
        self.lv_marker.adjustSize()
        lv_x, lv_y = self.transform_coordinates(*self.current_lv_coords)
        self.lv_marker.move(lv_x, lv_y)

        # Note: The zoom buttons remain static since they are children of the
        # scroll area's viewport.

    # Navigation and theme methods.
    def go_home(self):
        print("Home button clicked")

    def toggle_theme(self):
        self.dark_mode = not self.dark_mode
        self.apply_theme()

    def stop_action(self):
        print("Stop button clicked")

    def apply_theme(self):
        if self.dark_mode:
            self.stack.setStyleSheet("background: #222; color: white;")
        else:
            self.stack.setStyleSheet("background: white; color: black;")
        self.theme_button.setIcon(self.load_icon("b.png"))

    # Load an icon from file.
    def load_icon(self, filename):
        base_dir = os.path.dirname(os.path.abspath(__file__))
        full_path = os.path.join(base_dir, filename)
        return QtGui.QIcon(full_path) if os.path.exists(full_path) else QtGui.QIcon()

    # Load and scale a pixmap from file.
    def load_pixmap(self, filename, width, height):
        base_dir = os.path.dirname(os.path.abspath(__file__))
        full_path = os.path.join(base_dir, filename)
        pixmap = QtGui.QPixmap(full_path)
        if pixmap.isNull():
            print(f"Warning: Could not load pixmap from {full_path}")
        else:
            pixmap = pixmap.scaled(
                width, height, QtCore.Qt.KeepAspectRatio, QtCore.Qt.SmoothTransformation
            )
        return pixmap

    # Load a raw (unscaled) pixmap from file.
    def load_raw_pixmap(self, filename):
        base_dir = os.path.dirname(os.path.abspath(__file__))
        full_path = os.path.join(base_dir, filename)
        pixmap = QtGui.QPixmap(full_path)
        if pixmap.isNull():
            print(f"Warning: Could not load pixmap from {full_path}")
        return pixmap


if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    stack = QtWidgets.QStackedWidget()
    driving_screen = DrivingScreen(stack)
    stack.addWidget(driving_screen)
    stack.show()
    sys.exit(app.exec_())
