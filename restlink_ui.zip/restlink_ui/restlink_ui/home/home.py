#!/usr/bin/env python3
# Copyright (c) 2025 Hadi Miri. All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# pylint: disable=R0902,E1101,C0301,R0801,E023
import os

from PyQt5 import QtCore, QtGui, QtWidgets


class MainMenu(QtWidgets.QWidget):
    def __init__(self, stack):
        super().__init__()
        self.stack = stack
        self.dark_mode = False  # Theme state
        self.init_ui()
        self.setFixedSize(1000, 750)  # Set fixed window size

    def init_ui(self):
        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        # Top bar with home icon on the left and theme toggle on the right
        top_bar = QtWidgets.QHBoxLayout()

        # Home button (top-left corner)
        self.home_button = QtWidgets.QPushButton()
        self.home_button.setIcon(self.load_icon("home.png"))
        self.home_button.setIconSize(QtCore.QSize(32, 32))
        self.home_button.setFixedSize(40, 40)
        self.home_button.setStyleSheet("border: none; background: transparent;")
        self.home_button.clicked.connect(self.go_home)

        # Theme toggle button (top-right corner)
        self.theme_button = QtWidgets.QPushButton()
        self.theme_button.setIcon(self.load_icon("b.png"))  # Load icon safely
        self.theme_button.setFixedSize(32, 32)
        self.theme_button.setStyleSheet("border: none; background: transparent;")
        self.theme_button.clicked.connect(self.toggle_theme)

        # --- Added Stop Button ---
        self.stop_button = QtWidgets.QPushButton()
        self.stop_button.setIcon(self.load_icon("stop.png"))  # Load stop icon
        self.stop_button.setFixedSize(32, 32)
        self.stop_button.setStyleSheet(
            "border: none; background: transparent; margin-right: 5px;"
        )
        self.stop_button.clicked.connect(
            self.stop_action
        )  # Connect to stop_action method
        # --- End Added Stop Button ---

        top_bar.addWidget(self.home_button)  # Home icon on the left
        top_bar.addStretch()
        # Add stop button and theme button to the right side
        top_bar.addWidget(self.stop_button)
        top_bar.addWidget(self.theme_button)
        layout.addLayout(top_bar)

        # Title Label
        label = QtWidgets.QLabel("Welcome to RestLink\nPlease Choose Your Status")
        label.setAlignment(QtCore.Qt.AlignCenter)
        label.setStyleSheet(
            "font-size: 26px; font-weight: bold; background: transparent;"
        )
        layout.addWidget(label)

        # Logo
        logo_label = QtWidgets.QLabel()
        logo_pixmap = self.load_pixmap("logo.png", 350, 350)
        logo_label.setPixmap(logo_pixmap)
        logo_label.setAlignment(QtCore.Qt.AlignCenter)
        layout.addWidget(logo_label)

        # Buttons Layout with Images (using a separate widget)
        button_layout = ButtonLayoutWidget(self.stack, self)
        layout.addWidget(button_layout)
        # Expose the follower and lead buttons to the MainMenu widget.
        self.follower_button = button_layout.follower_button
        self.lead_button = button_layout.lead_button

        self.setLayout(layout)
        self.setWindowTitle("RestLink Main Menu")
        self.apply_theme()

    def go_home(self):
        """Go to the home screen (or perform home button action)."""
        print("Home button clicked")

    def toggle_theme(self):
        """Toggle dark/light mode for the whole UI."""
        self.dark_mode = not self.dark_mode
        self.apply_theme()

    def stop_action(self):
        """Action performed when the stop button is clicked."""
        print("Stop button clicked")
        # Add any additional functionality here.

    def apply_theme(self):
        """Applies the current theme to all elements properly."""
        if self.dark_mode:
            self.stack.setStyleSheet("background: #222; color: white;")
        else:
            self.stack.setStyleSheet("background: white; color: black;")
        self.theme_button.setIcon(self.load_icon("b.png"))

    def load_icon(self, filename):
        """Load an icon using an absolute path relative to this file."""
        base_dir = os.path.dirname(os.path.abspath(__file__))
        full_path = os.path.join(base_dir, filename)
        return QtGui.QIcon(full_path) if os.path.exists(full_path) else QtGui.QIcon()

    def load_pixmap(self, filename, width, height):
        """Load an image using an absolute path relative to this file."""
        base_dir = os.path.dirname(os.path.abspath(__file__))
        full_path = os.path.join(base_dir, filename)
        pixmap = QtGui.QPixmap(full_path)
        if pixmap.isNull():
            print(f"Warning: Could not load pixmap from {full_path}")
        else:
            pixmap = pixmap.scaled(
                width, height, QtCore.Qt.KeepAspectRatio, QtCore.Qt.SmoothTransformation
            )
        return pixmap


class ButtonLayoutWidget(QtWidgets.QWidget):
    """Separate widget for button layout with larger images."""

    def __init__(self, stack, parent):
        super().__init__()
        self.stack = stack
        self.parent = parent
        self.setStyleSheet("background: transparent;")
        button_layout = QtWidgets.QHBoxLayout(self)

        # Follower Vehicle
        self.follower_layout = QtWidgets.QVBoxLayout()
        self.follower_image = QtWidgets.QLabel()
        self.follower_image.setPixmap(
            self.load_pixmap("following_vehicle.png", 350, 250)
        )
        self.follower_image.setAlignment(QtCore.Qt.AlignCenter)
        self.follower_button = QtWidgets.QPushButton("Follower Vehicle")
        self.follower_button.setFixedHeight(60)
        self.follower_button.setStyleSheet("background-color: grey; font-size: 18px;")
        # Remove internal navigation here; the main app will handle navigation.
        self.follower_layout.addWidget(self.follower_image)
        self.follower_layout.addWidget(self.follower_button)

        # Lead Vehicle
        self.lead_layout = QtWidgets.QVBoxLayout()
        self.lead_image = QtWidgets.QLabel()
        self.lead_image.setPixmap(self.load_pixmap("lead_vehicle.png", 350, 250))
        self.lead_image.setAlignment(QtCore.Qt.AlignCenter)
        self.lead_button = QtWidgets.QPushButton("Lead Vehicle")
        self.lead_button.setFixedHeight(60)
        self.lead_button.setStyleSheet("background-color: grey; font-size: 18px;")
        # Remove internal navigation here; the main app will handle navigation.
        self.lead_layout.addWidget(self.lead_image)
        self.lead_layout.addWidget(self.lead_button)

        button_layout.addLayout(self.follower_layout)
        button_layout.addLayout(self.lead_layout)
        self.setLayout(button_layout)

    def load_pixmap(self, filename, width, height):
        """Load an image using an absolute path relative to this file."""
        base_dir = os.path.dirname(os.path.abspath(__file__))
        full_path = os.path.join(base_dir, filename)
        pixmap = QtGui.QPixmap(full_path)
        if pixmap.isNull():
            print(f"Warning: Could not load pixmap from {full_path}")
        else:
            pixmap = pixmap.scaled(
                width, height, QtCore.Qt.KeepAspectRatio, QtCore.Qt.SmoothTransformation
            )
        return pixmap


if __name__ == "__main__":
    app = QtWidgets.QApplication([])
    stack = QtWidgets.QStackedWidget()
    main_menu = MainMenu(stack)
    stack.addWidget(main_menu)
    stack.show()
    app.exec_()
