#!/usr/bin/env python3
from setuptools import find_packages, setup

package_name = 'restlink_ui'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(),  # Automatically finds restlink_ui and its subpackages
    data_files=[
        ('share/ament_index/resource_index/packages',
         ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    include_package_data=True,
    package_data={
        package_name: [
            'app/*.png',
            'destination/*.png',
            'done/*.png',
            'done/*.gif',
            'exit/*.png',
            'home/*.png',
            'lead_vehicle/*.png',
            'loading/*.png',
            'loading/*.gif',
            'map/*.png',
            'platoon/*.png',
            # Added for acceptance/accepted screens:
            'acceptance/*.png',
            'acceptance/*.gif',
            'accepted/*.png',
            'accepted/*.gif',
        ],
    },
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='hadi',
    maintainer_email='hadimiri24@gmail.com',
    description='User Interface Software for RestLink',
    license='MIT',
    tests_require=['pytest'],
    # Adding the scripts keyword ensures that main.py is installed as an executable.
    scripts=['restlink_ui/main.py'],
    entry_points={
        'console_scripts': [
            'restlink_ui = restlink_ui.main:main'
        ],
    },
)

