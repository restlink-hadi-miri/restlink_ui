#!/usr/bin/env python3
# Copyright (c) 2025 Hadi Miri. All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# pylint: disable=R0902,E1101,C0301,R0801,E023
import os
import sys

from PyQt5 import QtCore, QtGui, QtWidgets


class TruckJoinRequestScreen(QtWidgets.QWidget):
    def __init__(self, stack):
        super().__init__()
        self.stack = stack
        self.dark_mode = False
        self.init_ui()
        self.setFixedSize(1000, 750)

    def init_ui(self):
        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        top_bar = QtWidgets.QHBoxLayout()

        self.home_button = QtWidgets.QPushButton()
        self.home_button.setIcon(self.load_icon("home.png"))
        self.home_button.setIconSize(QtCore.QSize(32, 32))
        self.home_button.setFixedSize(40, 40)
        self.home_button.setStyleSheet("border: none; background: transparent;")
        self.home_button.clicked.connect(self.go_home)

        self.theme_button = QtWidgets.QPushButton()
        self.theme_button.setIcon(self.load_icon("b.png"))
        self.theme_button.setFixedSize(32, 32)
        self.theme_button.setStyleSheet("border: none; background: transparent;")
        self.theme_button.clicked.connect(self.toggle_theme)

        top_bar.addWidget(self.home_button)
        top_bar.addStretch()
        top_bar.addWidget(self.theme_button)
        layout.addLayout(top_bar)

        self.title_label = QtWidgets.QLabel(
            "Request of a truck to join the platoon is received"
        )
        self.title_label.setAlignment(QtCore.Qt.AlignCenter)
        self.title_label.setStyleSheet(
            "font-size: 26px; font-weight: bold; background: transparent;"
        )
        layout.addWidget(self.title_label)

        request_label = QtWidgets.QLabel()
        request_movie = QtGui.QMovie(self.get_resource_path("request.png"))
        request_movie.setScaledSize(QtCore.QSize(200, 200))
        request_movie.setCacheMode(QtGui.QMovie.CacheAll)
        request_movie.setSpeed(100)
        request_label.setMovie(request_movie)
        request_label.setAlignment(QtCore.Qt.AlignCenter)
        request_movie.start()
        layout.addWidget(request_label)

        logo_label = QtWidgets.QLabel()
        logo_pixmap = self.load_pixmap("logo.png", 150, 150)
        logo_label.setPixmap(logo_pixmap)
        logo_label.setAlignment(QtCore.Qt.AlignCenter)
        layout.addWidget(logo_label)

        self.setLayout(layout)
        self.setWindowTitle("RestLink Truck Join Request Page")
        self.apply_theme()

    def get_resource_path(self, filename):
        base_dir = os.path.dirname(os.path.abspath(__file__))
        return os.path.join(base_dir, filename)

    def go_home(self):
        print("Home button clicked")

    def toggle_theme(self):
        self.dark_mode = not self.dark_mode
        self.apply_theme()

    def apply_theme(self):
        if self.dark_mode:
            self.stack.setStyleSheet("background: #222; color: white;")
        else:
            self.stack.setStyleSheet("background: white; color: black;")
        self.theme_button.setIcon(self.load_icon("b.png"))

    def load_icon(self, filename):
        base_dir = os.path.dirname(os.path.abspath(__file__))
        full_path = os.path.join(base_dir, filename)
        return QtGui.QIcon(full_path) if os.path.exists(full_path) else QtGui.QIcon()

    def load_pixmap(self, filename, width, height):
        base_dir = os.path.dirname(os.path.abspath(__file__))
        full_path = os.path.join(base_dir, filename)
        pixmap = QtGui.QPixmap(full_path)
        if pixmap.isNull():
            print(f"Warning: Could not load pixmap from {full_path}")
        else:
            pixmap = pixmap.scaled(
                width, height, QtCore.Qt.KeepAspectRatio, QtCore.Qt.SmoothTransformation
            )
        return pixmap


if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    stack = QtWidgets.QStackedWidget()
    join_request_screen = TruckJoinRequestScreen(stack)
    stack.addWidget(join_request_screen)
    stack.show()
    sys.exit(app.exec_())
