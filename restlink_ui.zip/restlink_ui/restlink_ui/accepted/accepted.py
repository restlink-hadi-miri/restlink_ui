#!/usr/bin/env python3
# Copyright (c) 2025 Hadi Miri. All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# pylint: disable=R0902,E1101,C0301,R0801,E023
import os
import sys

from PyQt5 import QtCore, QtGui, QtWidgets


class AcceptedScreen(QtWidgets.QWidget):
    """A PyQt5 widget representing the 'Lead Vehicle Accepted' screen.

    Loads images from the local folder using absolute paths.
    """

    def __init__(self, stack):
        super().__init__()
        self.stack = stack
        self.dark_mode = False
        self.init_ui()
        # If you want a fixed window size, uncomment:
        # self.setFixedSize(1000, 750)

    def init_ui(self):
        """Builds the layout for the accepted screen, including:

        - A top bar with a home button, stop button, and theme toggle
        - A title label + checkmark icon
        - A logo
        """
        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        # Top Bar
        top_bar = QtWidgets.QHBoxLayout()

        self.home_button = QtWidgets.QPushButton()
        self.home_button.setIcon(self.load_icon("home.png"))
        self.home_button.setIconSize(QtCore.QSize(32, 32))
        self.home_button.setFixedSize(40, 40)
        self.home_button.setStyleSheet("border: none; background: transparent;")

        self.stop_button = QtWidgets.QPushButton()
        self.stop_button.setIcon(self.load_icon("stop.png"))
        self.stop_button.setFixedSize(32, 32)
        self.stop_button.setStyleSheet(
            "border: none; background: transparent; margin-right: 5px;"
        )

        self.theme_button = QtWidgets.QPushButton()
        self.theme_button.setIcon(self.load_icon("b.png"))
        self.theme_button.setFixedSize(32, 32)
        self.theme_button.setStyleSheet("border: none; background: transparent;")

        top_bar.addWidget(self.home_button)
        top_bar.addStretch()
        top_bar.addWidget(self.stop_button)
        top_bar.addWidget(self.theme_button)
        layout.addLayout(top_bar)

        # Title + checkmark
        title_widget = QtWidgets.QWidget()
        title_layout = QtWidgets.QHBoxLayout(title_widget)
        title_layout.setAlignment(QtCore.Qt.AlignCenter)

        title_label = QtWidgets.QLabel("Lead Vehicle Accepted the Request")
        title_label.setStyleSheet(
            "font-size: 26px; font-weight: bold; background: transparent;"
        )

        confirmation_icon = QtWidgets.QLabel()
        confirm_pixmap = self.load_pixmap("confirm.png", 40, 40)
        if not confirm_pixmap.isNull():
            confirmation_icon.setPixmap(confirm_pixmap)
            confirmation_icon.setAlignment(QtCore.Qt.AlignVCenter)
            title_layout.addWidget(title_label)
            title_layout.addWidget(confirmation_icon)
        else:
            # If confirm.png wasn't found, just show the label.
            title_layout.addWidget(title_label)

        layout.addWidget(title_widget, alignment=QtCore.Qt.AlignCenter)

        # Logo
        logo_label = QtWidgets.QLabel()
        logo_pixmap = self.load_pixmap("logo.png", 250, 250)
        if not logo_pixmap.isNull():
            logo_label.setPixmap(logo_pixmap)
            logo_label.setAlignment(QtCore.Qt.AlignCenter)
            layout.addWidget(logo_label)

        self.setLayout(layout)
        self.setWindowTitle("RestLink Confirmation Page")
        self.apply_theme()

    def load_icon(self, filename):
        """Loads an icon with absolute path."""
        return QtGui.QIcon(self.abs_path(filename))

    def load_pixmap(self, filename, width, height):
        """Loads a QPixmap from an absolute path, scaled to (width, height)."""
        pixmap = QtGui.QPixmap(self.abs_path(filename))
        if pixmap.isNull():
            print(f"Warning: Could not load '{filename}' in accepted screen.")
            return QtGui.QPixmap()
        return pixmap.scaled(
            width, height, QtCore.Qt.KeepAspectRatio, QtCore.Qt.SmoothTransformation
        )

    def abs_path(self, filename):
        """Returns the absolute path for a given filename in this folder."""
        base_dir = os.path.dirname(os.path.abspath(__file__))
        return os.path.join(base_dir, filename)

    def apply_theme(self):
        """Toggles between light/dark theme based on self.dark_mode.

        Re-applies icons if needed.
        """
        if self.dark_mode:
            self.stack.setStyleSheet("background: #222; color: white;")
        else:
            self.stack.setStyleSheet("background: white; color: black;")
        self.theme_button.setIcon(self.load_icon("b.png"))


if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    stack = QtWidgets.QStackedWidget()
    screen = AcceptedScreen(stack)
    stack.addWidget(screen)
    stack.show()
    sys.exit(app.exec_())
